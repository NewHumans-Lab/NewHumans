# Knowledge Ball 独立开发包 V3

日期：2026-09-15。当前采用状态：**UNDECIDED，最终由项目所有者决定是否替换旧版**。

主要设计见 [03_Knowledge_Ball.md](03_Knowledge_Ball.md)，包含认知引擎、展示与编辑组件、独立/世界两种接入、旧数据适配和 KB01—KB36 验收要求。

世界接入合同见 [08_Shared_Contracts.md](08_Shared_Contracts.md)。独立部署可以用自己的认证、本人确认、存储、预算和模型适配，不需要先做 Agent、社会组织或世界账本；费用仍须有明确承担者。

V3 重点是一个公共图与稀疏个人层、模型替换保持记忆、错误保留、个人挑战主动处理、人类代理共用本人记忆而不能替本人作最终判断。B / NOETIC OCEAN 是世界暂定主题，不能覆盖节点状态的语义。

参考目录包含 [完整总设计](reference/NewHumans_System_Spec_V3.md)、[修改说明](reference/NewHumans_Revision_Notes_V3.md) 和 [能量参数](reference/NewHumans_Energy_Policy_V3.json)。这些世界参考条款用于将来接入，不是独立知识产品必须一并部署的依赖。

本包不包含运行代码、迁移脚本或新 3D 资产。请按 M03 的盘点、适配、隔离比较和验收流程评估旧系统；开发新版不等于自动替换旧版。
